export function info(player) {
}
