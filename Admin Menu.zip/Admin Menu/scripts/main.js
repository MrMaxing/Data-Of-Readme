import * as mc from '@minecraft/server';
import * as fm from '@minecraft/server-ui';
mc.system.events.beforeWatchdogTerminate.subscribe(event => event.cancel = true);
import { gamemode } from './gamemode/index';
import { command_options } from './command options/index';
import { adjust_world } from './adjust world/index';
import { chat_options } from './chat options/index';
import { item_special } from './item special/index';
import { check_inventory } from './check inventory/index';
import { advanced } from './advanced/index';
import { credit } from './credit/index';
mc.world.events.beforeItemUse.subscribe((event) => {
    const player = event.source;
    const item = event.item;
    if (!item.nameTag?.startsWith('adminmenu'))
        return;
    event.cancel = true;
    if (!player.hasTag('admin'))
        return;
    const from = new fm.ActionFormData();
    from.title('Admin Menu');
    from.body(`     §8Addon Admin Menu Version 1.0.0§r\n§e» §rHello§r admin §l${player.name}§r\nWellcome to the addon admin menu!`);
    from.button('Game Mode\n§7Click to set game mode§r', 'textures/ui/sidebar_icons/character_creator');
    from.button('Command Options\n§7Click to use command§r', 'textures/ui/sidebar_icons/marketplace');
    from.button('Adjust World\n§7Click to adjust world§r', 'textures/ui/sidebar_icons/categories');
    from.button('Chat Options\n§7Click to use option§r', 'textures/ui/sidebar_icons/rounddonut');
    from.button('Items Special\n§7Click to get items§r', 'textures/ui/sidebar_icons/realms');
    from.button('Check Inventory\n§7Click to check inventory§r', 'textures/ui/sidebar_icons/capes');
    from.button('Advanced\n§7Click to advanced use§r', 'textures/ui/sidebar_icons/genre');
    from.button('Credit\n§7Click to see credit§r', 'textures/ui/sidebar_icons/bookmark');
    from.show(player).then(({ canceled, selection }) => {
        if (canceled)
            return;
        if (selection === 0)
            return gamemode(player);
        if (selection === 1)
            return command_options(player);
        if (selection === 2)
            return adjust_world(player);
        if (selection === 3)
            return chat_options(player);
        if (selection === 4)
            return item_special(player);
        if (selection === 5)
            return check_inventory(player);
        if (selection === 6)
            return advanced(player);
        if (selection === 7)
            return credit(player);
    });
});
