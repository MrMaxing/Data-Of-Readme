# [EN] Admin Menu
> Players must have an "admin" tag first. Then name any item.
> to be the "adminmenu" Then open the UI from the named item.

# [TH] Admin Menu
> ผู้เล่นต้องมี "admin" แท็กก่อน จากนั้นตั้งชื่อไอเทมอะไรก็ได้
> ให้เป็น "adminmenu" จากนั้นเปิด UI จากไอเทมที่ตั้งชื่อ