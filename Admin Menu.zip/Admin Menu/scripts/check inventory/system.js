import * as mc from '@minecraft/server';
export function getItem(player) {
    const inventory = player.getComponent('inventory').container;
    return [...Array(inventory.size).keys()].map(i => {
        const item = inventory.getItem(i);
        return { item, slot: i };
    }).filter(i => i.item instanceof mc.ItemStack);
}
export function clearItem(player, slot) {
    const inventory = player.getComponent('inventory').container;
    inventory.setItem(slot, new mc.ItemStack('minecraft:air'));
}
export function clearInventory(player) {
    const inventory = player.getComponent('inventory').container;
    Array.from(Array(inventory.size).keys()).forEach(i => {
        inventory.setItem(i, new mc.ItemStack('minecraft:air'));
    });
}
