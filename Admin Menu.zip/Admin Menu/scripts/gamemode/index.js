import * as mc from '@minecraft/server';
import * as fm from '@minecraft/server-ui';
import * as api from '../server/library.api';
function getGamemode(player) {
    return Object.values(mc.GameMode).find(gm => [...mc.world.getPlayers({
            name: player.name,
            gameMode: gm
        })].length);
}
export function gamemode(player) {
    const from = new fm.ActionFormData();
    from.title('Gamemode');
    from.body(`§e»§r You are now in ${getGamemode(player)} mode.`);
    from.button('Player Gamemode\n§7Click to set gamemode§r', 'textures/ui/promo_holiday_gift_small');
    from.button('Survival\n§7Click to set survival§r', 'textures/ui/promo_gift_small_green');
    from.button('Creative\n§7Click to set creative§r', 'textures/ui/promo_gift_small_yellow');
    from.button('Adventure\n§7Click to set adventure§r', 'textures/ui/promo_gift_small_pink');
    from.button('Spectator\n§7Click to set spectator§r', 'textures/ui/promo_gift_small_blue');
    from.show(player).then(({ canceled, selection }) => {
        if (canceled)
            return;
        if (selection === 0)
            return player_gamemode(player);
        if (selection === 1) {
            player.runCommandAsync('gamemode survival');
            player.sendMessage('§7Gamemode set to survival§r');
        }
        if (selection === 2) {
            player.runCommandAsync('gamemode creative');
            player.sendMessage('§7Gamemode set to creative§r');
        }
        if (selection === 3) {
            player.runCommandAsync('gamemode adventure');
            player.sendMessage('§7Gamemode set to adventure§r');
        }
        if (selection === 4) {
            player.runCommandAsync('gamemode spectator');
            player.sendMessage('§7Gamemode set to spectator§r');
        }
    });
}
function player_gamemode(player) {
    const All_Players = mc.world.getAllPlayers();
    const from = new fm.ActionFormData();
    from.title('Gamemode Player');
    from.body(`§e»§r Select a player to set gamemode.`);
    All_Players.forEach((player) => {
        from.button(`${player.name}\n§7Gamemode [§c${getGamemode(player)}§7]§r`, api.getFack());
    });
    from.button('Back\n§7Click to back§r', 'textures/ui/xbox_face_button_right');
    from.show(player).then(({ canceled, selection }) => {
        if (canceled)
            return;
        if (selection === All_Players.length)
            return gamemode(player);
        const target = All_Players[selection];
        const from = new fm.ActionFormData();
        from.title('Gamemode Player');
        from.body(`§e»§r Select a gamemode to set ${target.name}.`);
        from.button('Survival\n§7Click to set survival§r', 'textures/ui/promo_gift_small_green');
        from.button('Creative\n§7Click to set creative§r', 'textures/ui/promo_gift_small_yellow');
        from.button('Adventure\n§7Click to set adventure§r', 'textures/ui/promo_gift_small_pink');
        from.button('Spectator\n§7Click to set spectator§r', 'textures/ui/promo_gift_small_blue');
        from.button('Back\n§7Click to back§r', 'textures/ui/xbox_face_button_right');
        from.show(player).then(({ canceled, selection }) => {
            if (canceled)
                return;
            if (selection === 0) {
                target.runCommandAsync('gamemode survival');
                player.sendMessage('§7Gamemode set to survival§r');
            }
            if (selection === 1) {
                target.runCommandAsync('gamemode creative');
                player.sendMessage('§7Gamemode set to creative§r');
            }
            if (selection === 2) {
                target.runCommandAsync('gamemode adventure');
                player.sendMessage('§7Gamemode set to adventure§r');
            }
            if (selection === 3) {
                target.runCommandAsync('gamemode spectator');
                player.sendMessage('§7Gamemode set to spectator§r');
            }
            if (selection === 4)
                return player_gamemode(player);
        });
    });
}
