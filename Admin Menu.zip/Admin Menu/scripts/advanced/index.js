import * as mc from '@minecraft/server';
import * as fm from '@minecraft/server-ui';
import { Database } from '../server/library.database';
import './events';
export function advanced(player) {
    const from = new fm.ActionFormData();
    from.title('Advanced');
    from.body('§e»§r The system is still in development.');
    from.button('Gamerule\n§7Click to use§r', 'textures/ui/UpdateGlyph');
    from.button('Kick Pleyer\n§7Click to use§r', 'textures/ui/WarningGlyph');
    from.button('Ban Player\n§7Click to use§r', 'textures/ui/ErrorGlyph');
    from.show(player).then(({ canceled, selection }) => {
        if (canceled)
            return;
        if (selection === 0)
            return gamerule(player);
        if (selection === 1)
            return kick_player(player);
        if (selection === 2)
            return ban_player(player);
    });
}
function kick_player(player) {
    const All_Player = mc.world.getAllPlayers();
    const from = new fm.ModalFormData();
    from.title('Kick Player');
    from.dropdown('Select Player', All_Player.map(p => p.name));
    from.textField('Reason §c*required§r', 'Enter reason');
    from.show(player).then(({ canceled, formValues }) => {
        if (canceled)
            return;
        const target = All_Player[formValues[0]];
        const reason = formValues[1];
        mc.world.sendMessage(`[Server] Player ${target.name} was baned from the server because\n${reason}`);
        player.runCommandAsync(`kick "${target.name}" ${reason}`);
    });
}
function ban_player(player) {
    const db = new Database('ban_server');
    const from = new fm.ActionFormData();
    from.title('Ban Player');
    from.body('§e»§r The system bans the offending players.');
    from.button('Ban Player\n§7Click to Select Player§r', 'textures/ui/Ping_Offline_Red');
    from.button('Unban Player\n§7Click to Select Player§r', 'textures/ui/online');
    from.button('Back\n§7Click to go back§r', 'textures/ui/xbox_face_button_right');
    from.show(player).then(({ canceled, selection }) => {
        if (canceled)
            return;
        if (selection === 0) {
            const All_Player = mc.world.getAllPlayers();
            const from = new fm.ModalFormData();
            from.title('Ban Player');
            from.dropdown('Select Player', All_Player.map(p => p.name));
            from.textField('Reason §c*required§r', 'Enter reason');
            from.show(player).then(({ canceled, formValues }) => {
                if (canceled)
                    return;
                const target = All_Player[formValues[0]];
                const reason = formValues[1];
                mc.world.sendMessage(`[Server] Player ${target.name} was baned from the server because\n${reason}`);
                db.add(`${target.id}|${target.name}`, reason);
            });
        }
        if (selection === 1) {
            const All_Data = db.getData();
            if (All_Data.length === 0)
                return player.sendMessage(`§cThere are no banned players.`);
            const from = new fm.ModalFormData();
            from.title('Unban Player');
            from.dropdown('§e»§r Select Player to unban', All_Data.map(p => p.key.split('|')[1]));
            from.show(player).then(({ canceled, formValues }) => {
                if (canceled)
                    return;
                db.delete(All_Data[formValues[0]].key);
            });
        }
        if (selection === 2)
            return advanced(player);
    });
}
function gamerule(player) {
    const db = new Database('gamerule_server');
    const data = [
        {
            lable: 'Command Block Output',
            key: 'commandblockoutput',
            status: status_gamerule('commandblockoutput'),
            texture: 'textures/ui/UpdateGlyph'
        },
        {
            lable: 'Command Block Senabled',
            key: 'commandblocksenabled',
            status: status_gamerule('commandblocksenabled'),
            texture: 'textures/ui/UpdateGlyph'
        },
        {
            lable: 'Send Command Feedback',
            key: 'sendcommandfeedback',
            status: status_gamerule('sendcommandfeedback'),
            texture: 'textures/ui/UpdateGlyph'
        },
        {
            lable: 'Player Versus Player',
            key: 'pvp',
            status: status_gamerule('pvp'),
            texture: 'textures/ui/UpdateGlyph'
        }
    ];
    const from = new fm.ActionFormData();
    from.title('Gamerule');
    from.body('§e»§r The system allows you to change the gamerule of the server.');
    data.forEach(p => {
        from.button(`${p.lable}\n§7Click to ${p.status ? '§cdisable§r' : '§aenable§r'}§r`, p.texture);
    });
    from.button('Back\n§7Click to go back§r', 'textures/ui/xbox_face_button_right');
    from.show(player).then(({ canceled, selection }) => {
        if (canceled)
            return;
        if (selection === data.length)
            return advanced(player);
        const status = data[selection].status;
        const key = data[selection].key;
        if (status) {
            db.add(key, 'false');
            player.runCommandAsync(`gamerule ${key} false`);
            mc.world.sendMessage(`Gamerule ${key} §cdisabled§r`);
        }
        else {
            db.delete(key);
            player.runCommandAsync(`gamerule ${key} true`);
            mc.world.sendMessage(`Gamerule ${key} §aenabled§r`);
        }
    });
}
function status_gamerule(gamerule) {
    const db = new Database('gamerule_server');
    const data = db.getData();
    const status = data.find(p => p.key === gamerule);
    if (status)
        return false;
    return true;
}
