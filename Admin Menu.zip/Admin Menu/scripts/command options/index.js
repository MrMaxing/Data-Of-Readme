import * as mc from '@minecraft/server';
import * as fm from '@minecraft/server-ui';
import * as api from '../server/library.api';
export function command_options(player) {
    const from = new fm.ActionFormData();
    from.title('Command Options');
    from.body("§e»§r It's easier to use commands.");
    from.button('Teleport\n§7Click to use§r', 'textures/ui/sidebar_icons/my_characters');
    from.button('Scoreboard\n§7Click to use§r', 'textures/ui/sidebar_icons/my_content');
    from.button('Tags\n§7Click to use§r', 'textures/ui/sidebar_icons/promotag');
    from.button('Effects\n§7Click to use§r', 'textures/ui/sidebar_icons/featured');
    from.button('Levels\n§7Click to use§r', 'textures/ui/sidebar_icons/classic_skins');
    from.button('Announce\n§7Click to use§r', 'textures/ui/sidebar_icons/star');
    from.show(player).then(({ canceled, selection }) => {
        if (canceled)
            return;
        if (selection === 0)
            return teleport(player);
        if (selection === 1)
            return scoreboard(player);
        if (selection === 2)
            return tags(player);
        if (selection === 3)
            return effects(player);
        if (selection === 4)
            return levels(player);
        if (selection === 5)
            return announce(player);
    });
}
function teleport(player) {
    const All_Player = mc.world.getAllPlayers();
    const from = new fm.ActionFormData();
    from.title('Teleport');
    from.body('§e» §rSelect to teleport to a player§r');
    All_Player.forEach(player => {
        from.button(`${player.name}\n§7Click to teleport§r`, api.getFack());
    });
    from.button('Back\n§7Click to go back§r', 'textures/ui/xbox_face_button_right');
    from.show(player).then(({ canceled, selection }) => {
        if (canceled)
            return;
        if (selection === All_Player.length)
            return command_options(player);
        player.runCommandAsync(`tp @s "${All_Player[selection].name}"`);
        player.sendMessage(`Teleported to ${All_Player[selection].name}`);
    });
}
function scoreboard(player) {
    const from = new fm.ActionFormData();
    from.title('Scoreboard');
    from.body('§e» §rSelect to use scoreboard options§r');
    from.button('Objectives\n§7Click to use§r', 'textures/ui/xbox_face_button_down');
    from.button('Players\n§7Click to use§r', 'textures/ui/xbox_face_button_left');
    from.button('Back\n§7Click to go back§r', 'textures/ui/xbox_face_button_right');
    from.show(player).then(({ canceled, selection }) => {
        if (canceled)
            return;
        if (selection === 0)
            return objectives(player);
        if (selection === 1)
            return players(player);
        if (selection === 2)
            return command_options(player);
    });
}
function objectives(player) {
    const All_Objectives = mc.world.scoreboard.getObjectives().map(o => o.id);
    const short = ['ascending', 'descending'];
    const from = new fm.ActionFormData();
    from.title('Objectives');
    from.body('§e»§r Select to use objective options§r');
    from.button('Add Objective\n§7Click to add§r', 'textures/blocks/concrete_lime');
    from.button('Remove Objective\n§7Click to remove§r', 'textures/blocks/concrete_red');
    from.button('Set Display\n§7Click to set display§r', 'textures/blocks/concrete_yellow');
    from.button('Back\n§7Click to go back§r', 'textures/ui/xbox_face_button_right');
    from.show(player).then(({ canceled, selection }) => {
        if (canceled)
            return;
        if (selection === 0) {
            const from = new fm.ModalFormData();
            from.title('Add Objective');
            from.textField('§e»§r Enter Objective §c*required§r', 'name objective');
            from.textField('§e»§r Enter Display Name §a*optional§r', 'display name');
            from.show(player).then(({ canceled, formValues }) => {
                if (canceled)
                    return;
                const objective = formValues[0];
                const displayName = formValues[1];
                if (objective === '')
                    return player.sendMessage('Objective is §crequired§r');
                if (displayName === '')
                    player.runCommandAsync(`scoreboard objectives add "${objective}" dummy`);
                else
                    player.runCommandAsync(`scoreboard objectives add "${objective}" dummy "${displayName}"`);
                return player.sendMessage(`Added Objective: ${objective}`);
            });
        }
        if (All_Objectives.length === 0)
            return player.sendMessage('§cWorld not have a Objective§r');
        if (selection === 1) {
            const from = new fm.ModalFormData();
            from.title('Remove Objective');
            from.dropdown('§e»§r Select Objective to Remove', All_Objectives);
            from.show(player).then(({ canceled, formValues }) => {
                if (canceled)
                    return;
                const objective = All_Objectives[formValues[0]];
                player.runCommandAsync(`scoreboard objectives remove "${objective}"`);
                player.sendMessage(`Removed Objective: ${objective}`);
            });
        }
        if (selection === 2) {
            const from = new fm.ActionFormData();
            from.title('Set Display');
            from.body('§e»§r Select Display Options');
            from.button('Belowname\n§7Click to set display§r', 'textures/blocks/concrete_black');
            from.button('List\n§7Click to set display§r', 'textures/blocks/concrete_gray');
            from.button('Sidebar\n§7Click to set display§r', 'textures/blocks/concrete_silver');
            from.button('Back\n§7Click to go back§r', 'textures/ui/xbox_face_button_right');
            from.show(player).then(({ canceled, selection }) => {
                if (canceled)
                    return;
                if (selection === 0) {
                    const from = new fm.ModalFormData();
                    from.title('Set Belowname');
                    from.dropdown('§e»§r Select Score Objectives', All_Objectives);
                    from.toggle('§a»§r Clear Belowname', false);
                    from.show(player).then(({ canceled, formValues }) => {
                        if (canceled)
                            return;
                        if (formValues[1] == true)
                            return player.runCommandAsync(`scoreboard objectives setdisplay belowname`);
                        const objective = All_Objectives[formValues[0]];
                        player.runCommandAsync(`scoreboard objectives setdisplay belowname "${objective}"`);
                        player.sendMessage(`Set Display Belowname: ${objective}`);
                    });
                }
                if (selection === 1) {
                    const from = new fm.ModalFormData();
                    from.title('Set List');
                    from.dropdown('§e»§r Select Score Objectives', All_Objectives);
                    from.dropdown('§e»§r Select Short Scoreborad', short);
                    from.toggle('§a»§r Clear List', false);
                    from.show(player).then(({ canceled, formValues }) => {
                        if (canceled)
                            return;
                        if (formValues[2] == true)
                            return player.runCommandAsync(`scoreboard objectives setdisplay list`);
                        const objective = All_Objectives[formValues[0]];
                        const cending = short[formValues[1]];
                        player.runCommandAsync(`scoreboard objectives setdisplay list "${objective}" ${cending}`);
                        player.sendMessage(`Set Display List: ${objective}`);
                    });
                }
                if (selection === 2) {
                    const from = new fm.ModalFormData();
                    from.title('Set Sidebar');
                    from.dropdown('§e»§r Select Score Objectives', All_Objectives);
                    from.dropdown('§e»§r Select Short Scoreborad', short);
                    from.toggle('§a»§r Clear Sidebar', false);
                    from.show(player).then(({ canceled, formValues }) => {
                        if (canceled)
                            return;
                        if (formValues[2] == true)
                            return player.runCommandAsync(`scoreboard objectives setdisplay sidebar`);
                        const objective = All_Objectives[formValues[0]];
                        const cending = short[formValues[1]];
                        player.runCommandAsync(`scoreboard objectives setdisplay sidebar "${objective}" ${cending}`);
                        player.sendMessage(`Set Display sidebar: ${objective}`);
                    });
                }
                if (selection === 3)
                    return objectives(player);
            });
        }
        if (selection === 3)
            return scoreboard(player);
    });
}
function players(player) {
    const All_Objectives = mc.world.scoreboard.getObjectives().map(o => o.id);
    if (All_Objectives.length === 0)
        return player.sendMessage('§cWorld not have a Objective§r');
    const from = new fm.ActionFormData();
    from.title('Players');
    from.body('§e»§r Select to use player options§r');
    from.button('Add\n§7Click to add score§r', 'textures/blocks/concrete_red');
    from.button('Remove\n§7Click to remove score§r', 'textures/blocks/concrete_orange');
    from.button('Set\n§7Click to set score§r', 'textures/blocks/concrete_yellow');
    from.button('Reset\n§7Click to reset score§r', 'textures/blocks/concrete_lime');
    from.button('List\n§7Click to view list score§r', 'textures/blocks/concrete_cyan');
    from.button('Random\n§7Click to random score§r', 'textures/blocks/concrete_magenta');
    from.button('Back\n§7Click to go back§r', 'textures/ui/xbox_face_button_right');
    from.show(player).then(({ canceled, selection }) => {
        if (canceled)
            return;
        if (selection === 0) {
            const All_Players = mc.world.getAllPlayers();
            const from = new fm.ModalFormData();
            from.title('Add Score');
            from.dropdown('§e»§r Select Players', All_Players.map(p => p.name));
            from.dropdown('§e»§r Select Score Objectives', All_Objectives);
            from.textField('§e»§r Enter Score§ §c*required§r', 'score');
            from.toggle('§a»§r All Players', false);
            from.show(player).then(({ canceled, formValues }) => {
                if (canceled)
                    return;
                const target = All_Players[formValues[0]];
                const objective = All_Objectives[formValues[1]];
                const score = Number(formValues[2]);
                const all = formValues[3] == true ? '@a' : '@s';
                if (isNaN(score))
                    return player.sendMessage('§cEnter Only Numbers§r');
                target.runCommandAsync(`scoreboard players add ${all} "${objective}" ${score}`);
                player.sendMessage(`Added Score: ${objective}`);
            });
        }
        if (selection === 1) {
            const All_Players = mc.world.getAllPlayers();
            const from = new fm.ModalFormData();
            from.title('Removed Score');
            from.dropdown('§e»§r Select Players', All_Players.map(p => p.name));
            from.dropdown('§e»§r Select Score Objectives', All_Objectives);
            from.textField('§e»§r Enter Score§ §c*required§r', 'score');
            from.toggle('§a»§r All Players', false);
            from.show(player).then(({ canceled, formValues }) => {
                if (canceled)
                    return;
                const target = All_Players[formValues[0]];
                const objective = All_Objectives[formValues[1]];
                const score = Number(formValues[2]);
                const all = formValues[3] == true ? '@a' : '@s';
                if (isNaN(score))
                    return player.sendMessage('§cEnter Only Numbers§r');
                target.runCommandAsync(`scoreboard players remove ${all} "${objective}" ${score}`);
                player.sendMessage(`Removed Score: ${objective}`);
            });
        }
        if (selection === 2) {
            const All_Players = mc.world.getAllPlayers();
            const from = new fm.ModalFormData();
            from.title('Set Score');
            from.dropdown('§e»§r Select Players', All_Players.map(p => p.name));
            from.dropdown('§e»§r Select Score Objectives', All_Objectives);
            from.textField('§e»§r Enter Score§ §c*required§r', 'score');
            from.toggle('§a»§r All Players', false);
            from.show(player).then(({ canceled, formValues }) => {
                if (canceled)
                    return;
                const target = All_Players[formValues[0]];
                const objective = All_Objectives[formValues[1]];
                const score = Number(formValues[2]);
                const all = formValues[3] == true ? '@a' : '@s';
                if (isNaN(score))
                    return player.sendMessage('§cEnter Only Numbers§r');
                target.runCommandAsync(`scoreboard players set ${all} "${objective}" ${score}`);
                player.sendMessage(`Set Score: ${objective}`);
            });
        }
        if (selection === 3) {
            const All_Players = mc.world.getAllPlayers();
            const from = new fm.ModalFormData();
            from.title('Reset Score');
            from.dropdown('§e»§r Select Players', All_Players.map(p => p.name));
            from.dropdown('§e»§r Select Score Objectives', All_Objectives);
            from.toggle('§a»§r All Players', false);
            from.show(player).then(({ canceled, formValues }) => {
                if (canceled)
                    return;
                const target = All_Players[formValues[0]];
                const objective = All_Objectives[formValues[1]];
                const all = formValues[2] == true ? '@a' : '@s';
                target.runCommandAsync(`scoreboard players reset ${all} "${objective}"`);
                player.sendMessage(`Reset Score: ${objective}`);
            });
        }
        if (selection === 4) {
            const All_Players = mc.world.getAllPlayers();
            const from = new fm.ActionFormData();
            from.title('List Score');
            from.body('§e»§r Select Players');
            All_Players.forEach(player => {
                from.button(`${player.name}\n§7Click to view list§r`, api.getFack());
            });
            from.button('Back\n§7Click to go back§r', 'textures/ui/xbox_face_button_right');
            from.show(player).then(({ canceled, selection }) => {
                if (canceled)
                    return;
                if (selection === 0) {
                    const target = All_Players[selection];
                    const from = new fm.ActionFormData();
                    from.title('List Score');
                    from.body(`This is All Score of ${target.name}\n${All_Objectives.map(o => `§c»§r ${o} : ${api.getScore(o, target)}`).join('\n')}`);
                    from.button('Close\n§7Click to Close§r', 'textures/ui/xbox_face_button_right');
                }
            });
        }
        if (selection === 5) {
            const All_Players = mc.world.getAllPlayers();
            const from = new fm.ModalFormData();
            from.title('Random Score');
            from.dropdown('§e»§r Select Players', All_Players.map(p => p.name));
            from.dropdown('§e»§r Select Score Objectives', All_Objectives);
            from.textField('§e»§r Enter Score Min§ §c*required§r', 'score');
            from.textField('§e»§r Enter Score Max§ §c*required§r', 'score');
            from.toggle('§a»§r All Players', false);
            from.show(player).then(({ canceled, formValues }) => {
                if (canceled)
                    return;
                const target = All_Players[formValues[0]];
                const objective = All_Objectives[formValues[1]];
                const scoreMin = Number(formValues[2]);
                const scoreMax = Number(formValues[3]);
                const all = formValues[4] == true ? '@a' : '@s';
                if (isNaN(scoreMin) || isNaN(scoreMax))
                    return player.sendMessage('§cEnter Only Numbers§r');
                if (scoreMin > scoreMax)
                    return player.sendMessage('§cEnter Score Min <= Score Max§r');
                target.runCommandAsync(`scoreboard players random ${all} "${objective}" ${scoreMin} ${scoreMax}`);
                player.sendMessage(`Random Score: ${objective}, Result: ${api.getScore(objective, target)}`);
            });
        }
        if (selection === 6)
            return scoreboard(player);
    });
}
function tags(player) {
    const from = new fm.ActionFormData();
    from.title('Tags');
    from.body('§e»§r Select Tags Options');
    from.button('Add Tag\n§7Click to Add Tag§r', 'textures/ui/xbox_face_button_down');
    from.button('Remove Tag\n§7Click to Remove Tag§r', 'textures/ui/xbox_face_button_left');
    from.button('List Tags\n§7Click to List Tags§r', 'textures/ui/xbox_face_button_up');
    from.button('Back\n§7Click to go back§r', 'textures/ui/xbox_face_button_right');
    from.show(player).then(({ canceled, selection }) => {
        if (canceled)
            return;
        const All_Players = mc.world.getAllPlayers();
        const All_Tags = [...new Set(mc.world.getAllPlayers().map(p => p.getTags()).flat())];
        if (selection === 0) {
            const from = new fm.ModalFormData();
            from.title('Add Tag');
            from.dropdown('§c»§r Select Players', All_Players.map(p => p.name));
            from.dropdown('§6»§r Select Old Tags', All_Tags);
            from.textField('§e»§r Enter New Tag', 'tag');
            from.toggle('§a»§r All Players', false);
            from.toggle('§b»§r Old Tags or New Tag', false);
            from.show(player).then(({ canceled, formValues }) => {
                if (canceled)
                    return;
                const target = All_Players[formValues[0]];
                const all = formValues[3];
                const tag = formValues[4] == true ? formValues[2] : All_Tags[formValues[1]];
                if (formValues[4] == true)
                    if (tag === '' || Number(tag))
                        return player.sendMessage('§cEnter Only Text§r');
                if (all == true) {
                    mc.world.getAllPlayers().forEach(p => p.addTag(tag));
                    player.sendMessage(`Added Tag: ${tag} to everyone`);
                }
                else {
                    target.addTag(tag);
                    player.sendMessage(`Added Tag: ${tag} to ${target.name}`);
                }
            });
        }
        if (selection === 1) {
            const from = new fm.ActionFormData();
            from.title('Remove Tag');
            from.button('All Players\n§7Click to remove tag§r', 'textures/ui/xbox_face_button_down');
            All_Players.forEach(player => {
                from.button(`${player.name}\n§7Click to remove tag§r`, api.getFack());
            });
            from.button('Back\n§7Click to go back§r', 'textures/ui/xbox_face_button_right');
            from.show(player).then(({ canceled, selection }) => {
                if (canceled)
                    return;
                if (selection === 0) {
                    const from = new fm.ModalFormData();
                    from.title('Remove Tag');
                    from.dropdown('§e»§r Select Tags', All_Tags);
                    from.toggle('§b»§r Clear Tags', false);
                    from.show(player).then(({ canceled, formValues }) => {
                        if (canceled)
                            return;
                        const tag = All_Tags[formValues[0]];
                        if (formValues[1] == true) {
                            All_Tags.forEach(t => All_Players.filter(p => p.hasTag(t)).forEach(p => p.removeTag(t)));
                            player.sendMessage(`Clear tags from everyone`);
                        }
                        else {
                            All_Players.filter(p => p.hasTag(tag)).forEach(p => p.removeTag(tag));
                            player.sendMessage(`Removed Tag: ${tag} from everyone`);
                        }
                    });
                }
                else if (selection === All_Players.length + 1)
                    return tags(player);
                else {
                    const target = All_Players[selection - 1];
                    const All_TagsTarget = target.getTags();
                    if (All_TagsTarget.length === 0)
                        return player.sendMessage(`§c${target.name} has no tags§r`);
                    const from = new fm.ModalFormData();
                    from.title(`Remove Tag ${target.name}`);
                    from.dropdown('§e»§r Select Tags', All_TagsTarget);
                    from.toggle('§b»§r Clear Tags', false);
                    from.show(player).then(({ canceled, formValues }) => {
                        if (canceled)
                            return;
                        const tag = All_TagsTarget[formValues[0]];
                        if (formValues[1] == true) {
                            mc.world.getAllPlayers().find(p => p === target).getTags().forEach(t => target.removeTag(t));
                            player.sendMessage(`Clear tags from ${target.name}`);
                        }
                        else {
                            target.removeTag(tag);
                            player.sendMessage(`Removed Tag: ${tag} from ${target.name}`);
                        }
                    });
                }
            });
        }
        if (selection === 2) {
            const from = new fm.ActionFormData();
            from.title('List Score');
            from.body('§e»§r Select Player');
            All_Players.forEach(player => {
                from.button(`${player.name}\n§7Click to view list§r`, api.getFack());
            });
            from.button('Back\n§7Click to go back§r', 'textures/ui/xbox_face_button_right');
            from.show(player).then(({ canceled, selection }) => {
                if (canceled)
                    return;
                if (selection === All_Players.length)
                    return tags(player);
                const target = All_Players[selection];
                const from = new fm.ActionFormData();
                from.title('List Score');
                from.body(`This is All Tags of ${target.name}\n${target.getTags().map(t => `§c»§r ${t}`).join('\n')}`);
                from.button('Close\n§7Click to Close§r', 'textures/ui/xbox_face_button_right');
                from.show(player);
            });
        }
        if (selection === 3)
            return command_options(player);
    });
}
function effects(player) {
    const All_Players = mc.world.getAllPlayers();
    const All_Effects = Object.values(mc.MinecraftEffectTypes).filter(e => !e.getName().startsWith('empty'));
    const from = new fm.ModalFormData();
    from.title('Effects');
    from.dropdown('§c»§r Select Players', All_Players.map(p => p.name));
    from.dropdown('§6»§r Select Effects', All_Effects.map(e => e.getName()));
    from.textField('§e»§r Enter Duration Effect', 'Type Numbers');
    from.textField('§a»§r Enter Amplifier Effect', 'Type Numbers');
    from.toggle('§9»§r Show Particle', false);
    from.toggle('§3»§r Clear Effect', false);
    from.toggle('§d»§r All Players', false);
    from.show(player).then(({ canceled, formValues }) => {
        if (canceled)
            return;
        const target = All_Players[formValues[0]];
        const effect = All_Effects[formValues[1]];
        const duration = Number(formValues[2]);
        const amplifier = Number(formValues[3]);
        const show = formValues[4] == true ? false : true;
        if (formValues[5] == false) {
            if (isNaN(duration) || isNaN(amplifier))
                return player.sendMessage('§cEnter only numbers§r');
            if (duration <= 0 || amplifier <= 0)
                return player.sendMessage('§cEnter Numbers > 0§r');
        }
        if (formValues[6] == true) {
            if (formValues[5] == true) {
                player.runCommandAsync('effect @a clear');
                player.sendMessage(`Cleared all effects of everyone`);
            }
            else {
                player.runCommandAsync(`effect @a ${effect.getName()} ${duration} ${amplifier} ${show}`);
                player.sendMessage(`Added Effect: ${effect.getName()} to everyone`);
            }
        }
        else {
            if (formValues[5] == true) {
                target.runCommandAsync('effect @s clear');
                player.sendMessage(`Cleared all effects of ${target.name}`);
            }
            else {
                target.runCommandAsync(`effect @s ${effect.getName()} ${duration} ${amplifier} ${show}`);
                player.sendMessage(`Added Effect: ${effect.getName()} to ${target.name}`);
            }
        }
    });
}
function levels(player) {
    const All_Players = mc.world.getAllPlayers();
    const from = new fm.ModalFormData();
    from.title('Levels');
    from.dropdown('§c»§r Select Players', All_Players.map(p => p.name));
    from.textField('§6»§r Enter Levels', 'Type Numbers');
    from.toggle('§d»§r All Players', false);
    from.toggle('§e»§r Clear Levels', false);
    from.show(player).then(({ canceled, formValues }) => {
        if (canceled)
            return;
        const target = All_Players[formValues[0]];
        const levels = Number(formValues[1]);
        if (formValues[3] == false) {
            if (isNaN(levels))
                return player.sendMessage('§cEnter only numbers§r');
            if (levels <= 0)
                return player.sendMessage('§cEnter Numbers > 0§r');
        }
        if (formValues[3] == true) {
            if (formValues[2] == true) {
                All_Players.forEach(p => p.resetLevel());
                player.sendMessage(`Cleared levels of everyone`);
            }
            else {
                player.resetLevel();
                player.sendMessage(`Cleared levels of ${target.name}`);
            }
        }
        else {
            if (formValues[2] == true) {
                All_Players.forEach(p => p.addLevels(levels));
                player.sendMessage(`Cleared levels of ${target.name}`);
            }
            else {
                target.addLevels(levels);
                player.sendMessage(`Added Levels: ${levels} to ${target.name}`);
            }
        }
    });
}
function announce(player) {
    const All_Players = mc.world.getAllPlayers();
    const from = new fm.ModalFormData();
    from.title('Announce');
    from.textField('§c»§r Enter Message', 'Type Message');
    from.show(player).then(({ canceled, formValues }) => {
        if (canceled)
            return;
        const message = formValues[0];
        if (message == '')
            return player.sendMessage('§cEnter Message§r');
        All_Players.forEach(p => p.sendMessage(`[§r§cS§6e§er§av§3e§dr§r] ${message}`));
    });
}
