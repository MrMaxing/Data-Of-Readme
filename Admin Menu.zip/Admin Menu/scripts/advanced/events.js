import * as mc from '@minecraft/server';
import { Database } from '../server/library.database';
mc.system.runInterval(() => {
    const db = new Database('ban_server');
    if (db.length() === 0)
        return;
    db.getData().forEach(({ key, value }) => {
        const All_Player = mc.world.getAllPlayers();
        const player = All_Player.find(p => p.id === key.split('|')[0]);
        if (!player)
            return;
        All_Player[Math.floor(Math.random() * All_Player.length)].runCommandAsync(`kick "${player.name}" ${value}`);
    });
}, 25);
