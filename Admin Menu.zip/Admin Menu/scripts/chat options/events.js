import * as mc from '@minecraft/server';
import { Database } from '../server/library.database';
mc.world.events.beforeChat.subscribe((events) => {
    const db = new Database('vulgar_message');
    const player = events.sender;
    const message = events.message.replaceAll(' ', '').toLocaleUpperCase();
    if (player.hasTag('ban_chat')) {
        events.cancel = true;
        return player.sendMessage(`§cYou are banned from this server.§r`);
    }
    for (let i = 0; i < db.length(); i++) {
        if (message.includes(db.getData()[i].value.toLocaleUpperCase())) {
            events.cancel = true;
            player.sendMessage(`§cPlease use words appropriately.§r`);
            break;
        }
    }
});
