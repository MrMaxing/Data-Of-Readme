import * as fm from '@minecraft/server-ui';
export function item_special(player) {
    const from = new fm.ActionFormData();
    from.title('Check Inventory');
    from.body('');
    from.button('CMD IMPULSE\n§7Give Now§r', 'textures/ui/ImpulseSquare');
    from.button('CMD CHAIN\n§7Give Now§r', 'textures/ui/ChainSquare');
    from.button('CMD REPEAT\n§7Give Now§r', 'textures/ui/RepeatSquare');
    from.button('STT BLOCK\n§7Give Now§r', 'textures/blocks/structure_block');
    from.button('STT VOID\n§7Give Now§r', 'textures/blocks/structure_void');
    from.button('Npc Egg\n§7Give Now§r', 'textures/items/egg_npc');
    from.button('BARRIER\n§7Give Now§r', 'textures/blocks/barrier');
    from.button('LIGHT BLOCK\n§7Give Now§r', 'textures/items/light_block_15');
    from.button('ALLOW\n§7Give Now§r', 'textures/blocks/build_allow');
    from.button('DENY\n§7Give Now§r', 'textures/blocks/build_deny');
    from.show(player).then(({ canceled, selection }) => {
        if (canceled)
            return;
        if (selection === 0) {
            player.playSound('note.bit');
            player.sendMessage('§cGive§r command_block');
            player.runCommandAsync(`give @s command_block 1`);
            return item_special(player);
        }
        if (selection === 1) {
            player.playSound('note.bit');
            player.sendMessage('§cGive§r chain_command_block');
            player.runCommandAsync(`give @s chain_command_block 1`);
            return item_special(player);
        }
        if (selection === 2) {
            player.playSound('note.bit');
            player.sendMessage('§cGive§r repeating_command_block');
            player.runCommandAsync(`give @s repeating_command_block 1`);
            return item_special(player);
        }
        if (selection === 3) {
            player.playSound('note.bit');
            player.sendMessage('§cGive§r structure_block');
            player.runCommandAsync(`give @s structure_block 1`);
            return item_special(player);
        }
        if (selection === 4) {
            player.playSound('note.bit');
            player.sendMessage('§cGive§r structure_void');
            player.runCommandAsync(`give @s structure_void 1`);
            return item_special(player);
        }
        if (selection === 5) {
            player.playSound('note.bit');
            player.sendMessage('§cGive§r Npc Egg');
            player.runCommandAsync(`give @s spawn_egg 1 51`);
            return item_special(player);
        }
        if (selection === 6) {
            player.playSound('note.bit');
            player.sendMessage('§cGive§r barrier');
            player.runCommandAsync(`give @s barrier 1`);
            return item_special(player);
        }
        if (selection === 7) {
            player.playSound('note.bit');
            lightBlock(player);
        }
        if (selection === 8) {
            player.playSound('note.bit');
            player.sendMessage('§cGive§r allow');
            player.runCommandAsync(`give @s allow 1`);
            return item_special(player);
        }
        if (selection === 9) {
            player.playSound('note.bit');
            player.sendMessage('§cGive§r deny');
            player.runCommandAsync(`give @s deny 1`);
            return item_special(player);
        }
    });
}
function lightBlock(player) {
    const from = new fm.ModalFormData();
    from.title('Light Block');
    from.slider('§eLight§r Level', 0, 15, 1);
    from.show(player).then(({ canceled, formValues }) => {
        if (canceled)
            return item_special(player);
        else {
            player.playSound('note.bit');
            player.sendMessage(`§cGive§r light block ${formValues[0]}`);
            player.runCommandAsync(`give @s light_block 1 ${formValues[0]}`);
            return item_special(player);
        }
    });
}
