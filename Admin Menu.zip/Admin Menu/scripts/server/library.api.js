import * as mc from '@minecraft/server';
import { getTexturesObject } from './library.texture';
/**
 * Retrieves the score of the specified player for the given scoreboard objective.
 * If the objective does not exist, it will be created.
 * @param {string} objective - The name of the scoreboard objective.
 * @param {mc.Player} player - The player whose score is being retrieved.
 * @returns {number} The player's score for the specified objective.
 */
export function getScore(objective, player) {
    try {
        player.runCommandAsync(`scoreboard players add @s ${objective} 0`);
        return mc.world.scoreboard.getObjective(objective).getScore(player.scoreboard);
    }
    catch {
        player.runCommandAsync(`scoreboard objectives add ${objective} dummy`);
        console.warn(`The object named ${objective} was not found.`);
    }
}
export class itemData {
    #item;
    /**
     * Creates a new itemData object with the specified ItemStack.
     * @param {mc.ItemStack} item - The ItemStack to get data from.
     */
    constructor(item) {
        this.#item = item;
    }
    /**
     * Gets name of the item.
     * @returns {string} The name of the item.
     */
    getName() {
        return this.#item.nameTag || setName(this.#item.typeId);
    }
    /**
     * Gets an array of all enchantments on the item.
     * @returns {Array<mc.Enchantment>} An array of enchantment objects.
     */
    getEnchantments() {
        return [...this.#item.getComponent('minecraft:enchantments').enchantments];
    }
    /**
     * Gets the lore of the item.
     * @returns {Array<string>} An array of lore strings.
     */
    getLore() {
        return this.#item.getLore().length <= 0 ? [] : this.#item.getLore();
    }
}
/**
    * @param {string} typeId
    * @returns {string} id to name
    */
export function setName(typeId) {
    return typeId.split(":")[1].split("_").map(m => m[0].toUpperCase() + m.slice(1)).join(" ");
}
export function useItem(callback, itemName) {
    mc.world.events.itemUse.subscribe((eventData) => {
        eventData.item.nameTag === itemName && callback(eventData);
    });
}
export function getFack() {
    const files = ['alex_icon', 'ari_icon', 'efe_icon', 'kai_icon', 'makena_icon', 'noor_icon', 'steve_icon', 'sunny_icon', 'zuri_icon'];
    return `textures/ui/default_cast/${files[Math.floor(Math.random() * files.length)]}.png`;
}
export function getTextures(typeId) {
    return getTexturesObject.get(typeId);
}
/**
 * @param {mc.Player} target
 * @param {CallableFunction} callback
 * @returns {void}
 */
export function doMove(target, callback) {
    const ui = mc.system.runInterval(() => {
        const v = target.getVelocity();
        const speed = Math.sqrt(v.x ** 2 + v.y ** 2 + v.z ** 2);
        if (speed > 0) {
            callback();
            mc.system.clearRun(ui);
        }
    }, 10);
}
