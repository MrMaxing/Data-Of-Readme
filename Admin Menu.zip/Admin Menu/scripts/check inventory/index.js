import * as mc from '@minecraft/server';
import * as fm from '@minecraft/server-ui';
import * as api from '../server/library.api';
import * as dp from './display';
import * as sy from './system';
export function check_inventory(player) {
    const All_Player = mc.world.getAllPlayers();
    const from = new fm.ActionFormData();
    from.title('Check Inventory');
    from.body('');
    All_Player.forEach(player => {
        from.button(`${player.name}\n§7Click to Check Inventory`, api.getFack());
    });
    from.show(player).then(({ canceled, selection }) => {
        if (canceled)
            return;
        else
            return check_list(player, All_Player[selection]);
    });
}
function check_list(player, target) {
    const All_Items = sy.getItem(target);
    const from = new fm.ActionFormData();
    from.title('Check Inventory');
    from.body('');
    dp.buttonSelectItem(target).forEach(({ name, textures }) => {
        from.button(name, textures);
    });
    from.button('Clear Items\n§7Click to Clear all items§r', 'textures/ui/ps4_face_button_left');
    from.button('Back\n§7Click to go back§r', 'textures/ui/xbox_face_button_right');
    from.show(player).then(({ canceled, selection }) => {
        if (canceled)
            return;
        if (selection === All_Items.length + 1)
            return check_inventory(player);
        if (selection !== All_Items.length)
            return check_item(player, target, All_Items[selection]);
        else {
            sy.clearInventory(target);
            target.sendMessage('§7All items have been cleared by Admin.§r');
            player.sendMessage(`§7Clear item of ${target.name}.§r`);
        }
    });
}
function check_item(player, target, data) {
    const from = new fm.ActionFormData();
    from.title('Check Inventory');
    from.body(dp.dataItem(data.item));
    from.button('Delete Items\n§7Click to delete items§r', 'textures/ui/ps4_face_button_left');
    from.button('Back\n§7Click to Back§r', 'textures/ui/ps4_face_button_right');
    from.show(player).then(({ canceled, selection }) => {
        if (canceled)
            return;
        if (selection === 0) {
            sy.clearItem(target, data.slot);
            target.sendMessage(`§7Item ${data.item.typeId} has been deleted by Admin.§r`);
            player.sendMessage(`§7Delete item ${data.item.typeId} of ${target.name}.§r`);
            return check_list(player, target);
        }
        if (selection === 1)
            return check_list(player, target);
    });
}
