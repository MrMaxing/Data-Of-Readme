import * as fm from '@minecraft/server-ui';
export function adjust_world(player) {
    const from = new fm.ActionFormData();
    from.title('Adjust World');
    from.body('');
    from.button('Set Time\n§7Click to set time§r', 'textures/ui/icon_summer');
    from.button('Set Weather\n§7Click to set weather§r', 'textures/ui/levitation_effect');
    from.button('Set Difficulty\n§7Click to set difficulty§r', 'textures/ui/resistance_effect');
    from.show(player).then(({ canceled, selection }) => {
        if (canceled)
            return;
        if (selection === 0)
            set_time(player);
        if (selection === 1)
            set_weather(player);
        if (selection === 2)
            set_difficulty(player);
    });
}
function set_time(player) {
    const from = new fm.ActionFormData();
    from.title('Set Time');
    from.body('');
    from.button('Sunrise\n§7Click to set sunrise§r', 'textures/ui/time_1sunrise');
    from.button('Day\n§7Click to set day§r', 'textures/ui/time_2day');
    from.button('Noon\n§7Click to set noon§r', 'textures/ui/time_3noon');
    from.button('Sunset\n§7Click to set sunset§r', 'textures/ui/time_4sunset');
    from.button('Night\n§7Click to set night§r', 'textures/ui/time_5night');
    from.button('Midnight\n§7Click to set midnight§r', 'textures/ui/time_6midnight');
    from.button('Back\n§7Click to go back§r', 'textures/ui/xbox_face_button_right');
    from.show(player).then(({ canceled, selection }) => {
        if (canceled)
            return;
        if (selection === 0) {
            player.runCommandAsync('time set sunrise');
            player.sendMessage('§7Set time to sunrise§r');
        }
        if (selection === 1) {
            player.runCommandAsync('time set day');
            player.sendMessage('§7Set time to day§r');
        }
        if (selection === 2) {
            player.runCommandAsync('time set noon');
            player.sendMessage('§7Set time to noon§r');
        }
        if (selection === 3) {
            player.runCommandAsync('time set sunset');
            player.sendMessage('§7Set time to sunset§r');
        }
        if (selection === 4) {
            player.runCommandAsync('time set night');
            player.sendMessage('§7Set time to night§r');
        }
        if (selection === 5) {
            player.runCommandAsync('time set midnight');
            player.sendMessage('§7Set time to midnight§r');
        }
        if (selection === 6)
            return adjust_world(player);
    });
}
function set_weather(player) {
    const from = new fm.ActionFormData();
    from.title('Set Weather');
    from.body('');
    from.button('Clear\n§7Click to clear weather§r', 'textures/ui/weather_clear');
    from.button('Rain\n§7Click to set rain§r', 'textures/ui/weather_rain');
    from.button('Thunderstorm\n§7Click to set thunder§r', 'textures/ui/weather_thunderstorm');
    from.button('Back\n§7Click to go back§r', 'textures/ui/xbox_face_button_right');
    from.show(player).then(({ canceled, selection }) => {
        if (canceled)
            return;
        if (selection === 0) {
            player.runCommandAsync('weather clear');
            player.sendMessage('§7Set weather to clear§r');
        }
        if (selection === 1) {
            player.runCommandAsync('weather rain');
            player.sendMessage('§7Set weather to rain§r');
        }
        if (selection === 2) {
            player.runCommandAsync('weather thunder');
            player.sendMessage('§7Set weather to thunder§r');
        }
        if (selection === 3)
            return adjust_world(player);
    });
}
function set_difficulty(player) {
    const from = new fm.ActionFormData();
    from.title('Set Difficulty');
    from.body('');
    from.button('Peaceful\n§7Click to set peaceful§r', 'textures/items/potion_bottle_jump');
    from.button('Easy\n§7Click to set easy§r', 'textures/items/potion_bottle_digSpeed');
    from.button('Normal\n§7Click to set normal§r', 'textures/items/potion_bottle_fireResistance');
    from.button('Hard\n§7Click to set hard§r', 'textures/items/potion_bottle_heal');
    from.button('Back\n§7Click to go back§r', 'textures/ui/xbox_face_button_right');
    from.show(player).then(({ canceled, selection }) => {
        if (canceled)
            return;
        if (selection === 0) {
            player.runCommandAsync('difficulty peaceful');
            player.sendMessage('§7Set difficulty to peaceful§r');
        }
        if (selection === 1) {
            player.runCommandAsync('difficulty easy');
            player.sendMessage('§7Set difficulty to easy§r');
        }
        if (selection === 2) {
            player.runCommandAsync('difficulty normal');
            player.sendMessage('§7Set difficulty to normal§r');
        }
        if (selection === 3) {
            player.runCommandAsync('difficulty hard');
            player.sendMessage('§7Set difficulty to hard§r');
        }
        if (selection === 4)
            return adjust_world(player);
    });
}
