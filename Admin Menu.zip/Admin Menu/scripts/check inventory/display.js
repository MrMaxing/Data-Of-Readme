import * as api from '../server/library.api';
import * as sy from './system';
function enchants(enchantList) {
    const showFrom = enchantList.length <= 0 ? 'No Enchantments' : `[\n${enchantList.map(enchant => `   ${enchant.type.id} : ${enchant.level}`).join('\n')}\n]`;
    const has = enchantList.length <= 0 ? '§7Enchant§r' : '§dEnchant§r';
    return { showFrom, has };
}
function lores(loreList) {
    return loreList.length <= 0 ? 'No Lore' : `[\n${loreList.join(',\n')}\n]`;
}
export function buttonSelectItem(player) {
    return sy.getItem(player).map(({ item, slot }) => {
        const items = new api.itemData(item);
        return {
            name: `${items.getName()}\n§r§cSlot§r [${slot}] ${enchants(items.getEnchantments()).has}§r`,
            textures: api.getTextures(item.typeId)
        };
    });
}
export function dataItem(item) {
    const itemData = new api.itemData(item);
    const data = [
        `§c»§r Name: §r${itemData.getName()}`,
        `§6»§r TypeId: §r${item.typeId}`,
        `§e»§r Enchant: §r${enchants(itemData.getEnchantments()).showFrom}`,
        `§a»§r Lore: §r${lores(itemData.getLore())}`,
        `§3»§r Amount: §r${item.amount}`,
    ];
    return [data[0], data[1], data[2], data[3], data[4]].join('\n');
}
