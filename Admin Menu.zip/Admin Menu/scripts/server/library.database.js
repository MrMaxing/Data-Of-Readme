import * as mc from '@minecraft/server';
/**
 * @author MSC BEEHI
 * @version 1.0.0
 * @description A database class for storing key-value pairs in Minecraft scoreboard objectives
 */
export class Database {
    /**
     * The name of the database (scoreboard objective)
     * @type {string} The name of the database
     */
    #DatabaseName;
    /**
     * The display name of the scoreboard objective
     * @type {string} The display name of the scoreboard objective
     */
    #DisplayName;
    /**
     * Creates a new database instance with the given name and optional display name
     * @param {string} DatabaseName - The name of the database
     * @example new Database('name')
     */
    constructor(DatabaseName) {
        try {
            this.#DatabaseName = DatabaseName;
            this.#DisplayName = `Database:${DatabaseName}`;
            if (this.#DatabaseName.length < 1)
                return;
            mc.world.scoreboard.addObjective(this.#DatabaseName, this.#DisplayName);
        }
        catch { }
    }
    /**
     * Retrieves all key-value pairs stored in the database
     * @returns {Array<{ key: string, value: string }>} - An array of key-value pairs
     */
    getData() {
        return mc.world.scoreboard.getObjective(this.#DatabaseName).getParticipants().map(data => ({
            key: data.displayName.split(':')[0],
            value: this.#base36ToValue(data.displayName.split(':')[1])
        }));
    }
    /**
     * Adds a new key-value pair to the database
     * @param {string} key - The key to add
     * @param {string} value - The value to add
     * @returns {Promise<mc.CommandResult>} - The result of the 'runCommand'
     */
    add(key, value) {
        return this.#runCommand(`scoreboard players set "${key}:${this.#valueToBase36(value)}" ${this.#DatabaseName} 0`);
    }
    /**
     * Deletes a key-value pair from the database
     * @param {string} key - The key to delete
     * @returns {Promise<mc.CommandResult>} - The result of the 'runCommand'
     */
    delete(key) {
        return this.#runCommand(`scoreboard players reset "${key}:${this.#valueToBase36(this.getValue(key))}" ${this.#DatabaseName}`);
    }
    /**
     * Clears all key-value pairs from the database
     * @returns {void} - deletes all key-value pairs from the database
     */
    clear() {
        try {
            return this.getData().forEach(data => this.delete(data.key));
        }
        catch { }
    }
    /**
     * Retrieves the key associated with a given value
     * @param {string} value - The value to search for
     * @returns {string} - The key associated with the given value, or an empty string if not found
     */
    getKey(value) {
        return this.getData().find(v => v.value === value)?.key || '';
    }
    /**
     * Retrieves the value associated with a given key
     * @param {string} key - The key to search for
     * @returns {string} - The value associated with the given key, or an empty string if not found
     */
    getValue(key) {
        return this.getData().find(k => k.key === key)?.value || '';
    }
    /**
     * Checks if a given key exists in the database
     * @param {string} key - The key to search for
     * @returns {boolean} - true if the key exists, false otherwise
     */
    has(key) {
        return typeof (this.getKey(key)) === undefined ? true : false;
    }
    length() {
        return this.getData().length;
    }
    /**
    * Runs a Minecraft server command asynchronously in the overworld dimension
    * @param {string} command - The command to be executed
    * @returns {Promise<void>} - A promise that resolves when the command has been executed
    */
    #runCommand(command) {
        return mc.world.getDimension('overworld').runCommandAsync(command);
    }
    /**
     * Encodes a string in base64 format
     * @param {string} value - The string to be encoded
     * @returns {string} - The base64 encoded string
     */
    #valueToBase36(value) {
        return value.split('').map(value => value.charCodeAt(0).toString(32)).join(' ');
    }
    /**
     * Decodes a base36 encoded string into a regular string
     * @param {string} base36 - The base36 encoded string to be decoded
     * @returns {string} - The decoded regular string
    */
    #base36ToValue(base36) {
        return base36.split(' ').map(value => String.fromCharCode(parseInt(value, 32))).join('');
    }
}
