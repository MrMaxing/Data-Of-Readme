import * as mc from '@minecraft/server';
import * as fm from '@minecraft/server-ui';
import * as api from '../server/library.api';
import { Database } from '../server/library.database';
import './events';
export function chat_options(player) {
    const from = new fm.ActionFormData();
    from.title('Chat Options');
    from.body('§e»§r Setting Chat Options');
    from.button('Priveate Chat\n§7Click to send message§r', 'textures/ui/mute_off');
    from.button('Vulgar Message\n§7Click to send message§r', 'textures/ui/ErrorGlyph');
    from.button('Ban Chat\n§7Click to ban player§r', 'textures/ui/mute_on');
    from.show(player).then(({ canceled, selection }) => {
        if (canceled)
            return;
        if (selection === 0)
            return priveate_chat(player);
        if (selection === 1)
            return vulgar_message(player);
        if (selection === 2)
            return ban_chat(player);
    });
}
function priveate_chat(player) {
    const All_Player = mc.world.getAllPlayers();
    const from = new fm.ModalFormData();
    from.title('Priveate Chat');
    from.dropdown('§e»§r Select Player', All_Player.map(p => p.name));
    from.textField('§e»§r Message §c*required§r', 'enter text');
    from.toggle('§e»§r identification of you', true);
    from.show(player).then(({ canceled, formValues }) => {
        if (canceled)
            return;
        const target = All_Player[formValues[0]];
        const message = formValues[1];
        const sender = formValues[2] == true ? player.name : 'System';
        if (message === '')
            return player.sendMessage('Message §crequired§r');
        target.sendMessage(`[§aPriveate§r] ${sender}: ${message}`);
    });
}
function vulgar_message(player) {
    const db = new Database('vulgar_message');
    const from = new fm.ActionFormData();
    from.title('Vulgar Message');
    from.body('§e»§r Setting Vulgar Message');
    from.button('Add Vulgar Message\n§7Click to add§r', 'textures/ui/xbox_face_button_down');
    from.button('Remove Vulgar Message\n§7Click to remove§r', 'textures/ui/xbox_face_button_up');
    from.button('Back\n§7Click to go back§r', 'textures/ui/xbox_face_button_right');
    from.show(player).then(({ canceled, selection }) => {
        if (canceled)
            return;
        if (selection === 0) {
            const from = new fm.ModalFormData();
            from.title('Add Vulgar Message');
            from.textField('§e»§r Message §c*required§r', 'enter text');
            from.show(player).then(({ canceled, formValues }) => {
                if (canceled)
                    return;
                if (formValues[0] === '')
                    return player.sendMessage('Message §crequired§r');
                db.add(`key${db.length()}`, formValues[0]);
                player.sendMessage(`§7Add the word ${formValues[0]} to the forbidden word.§r`);
            });
        }
        if (selection === 1) {
            if (db.length() === 0)
                return player.sendMessage('§cThere are no banned words.§r');
            const ALl_Data = db.getData();
            const from = new fm.ModalFormData();
            from.title('Remove Vulgar Message');
            from.dropdown('§e»§r Select Forbidden Word', ALl_Data.map(p => p.value));
            from.show(player).then(({ canceled, formValues }) => {
                if (canceled)
                    return;
                if (formValues[0] === '')
                    return player.sendMessage('Message §crequired§r');
                db.delete(ALl_Data[formValues[0]].key);
                player.sendMessage(`§7Remove the word ${formValues[0]} from the forbidden word.§r`);
            });
        }
        if (selection === 2)
            return chat_options(player);
    });
}
function ban_chat(player) {
    const from = new fm.ActionFormData();
    from.title('Ban Chat');
    const All_Player = mc.world.getAllPlayers().map(p => ({ data: player, name: p.name, status: p.hasTag('ban_chat') ? '§cBan§r' : '§aUnban§r' }));
    from.body('');
    All_Player.forEach(p => {
        from.button(`${p.name}\n§7Status §f[§r${p.status}§f]§r`, api.getFack());
    });
    from.button('Back\n§7Click to go back§r', 'textures/ui/xbox_face_button_right');
    from.show(player).then(({ canceled, selection }) => {
        if (canceled)
            return;
        if (selection === All_Player.length)
            return chat_options(player);
        const target = All_Player.map(p => p.data)[selection];
        if (target.hasTag('ban_chat')) {
            target.removeTag('ban_chat');
            target.sendMessage('§aYou have been unbanned from sending messages.§r');
        }
        else {
            target.addTag('ban_chat');
            target.sendMessage('§cYou have been banned from sending messages.§r');
        }
    });
}
