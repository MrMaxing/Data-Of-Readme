export function command_options(player) {
}
