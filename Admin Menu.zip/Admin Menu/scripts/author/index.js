import * as fm from '@minecraft/server-ui';
export function credit(player) {
    const from = new fm.ActionFormData();
    from.title('Credit');
    from.body(['     §8Addon Admin Menu Version 1.0.0§r',
        '§c»§r Author\n  §7Mr Maxing§r',
        '§6»§r Discord\n  §7https://discord.gg/RtEKe5kZkT§r',
        '§e»§r Github\n  §7https://github.com/MrMaxing§r',
        '§a»§r Youtube\n  §7Mr Maxing§r',
        `§3»§r Description\n  §7${[
            'This add-on is a helper for admins to manage',
            'the server more easily and has various ',
            'convenient systems.',
        ].join('\n')}§r`,
    ].join('\n'));
}
