import * as mc from '@minecraft/server';
import * as fm from '@minecraft/server-ui';
import * as api from '../server/library.api';
function getGamemode(player) {
    return Object.values(mc.GameMode).find(gm => [...mc.world.getPlayers({
            name: player.name,
            gameMode: gm
        })].length);
}
const All_Gamemode = [
    {
        lable: 'Survival\n§7Click to set survival§r',
        gamemode: 'survival',
        texture: 'textures/ui/promo_gift_small_green'
    },
    {
        lable: 'Creative\n§7Click to set creative§r',
        gamemode: 'creative',
        texture: 'textures/ui/promo_gift_small_yellow'
    },
    {
        lable: 'Adventure\n§7Click to set adventure§r',
        gamemode: 'adventure',
        texture: 'textures/ui/promo_gift_small_pink'
    },
    {
        lable: 'Spectator\n§7Click to set spectator§r',
        gamemode: 'spectator',
        texture: 'textures/ui/promo_gift_small_blue'
    }
];
export function gamemode(player) {
    const from = new fm.ActionFormData();
    from.title('Gamemode');
    from.body(`§e»§r You are now in ${getGamemode(player)} mode.`);
    from.button('Player Gamemode\n§7Click to set gamemode§r', 'textures/ui/promo_holiday_gift_small');
    All_Gamemode.forEach((gamemode) => {
        from.button(gamemode.lable, gamemode.texture);
    });
    from.show(player).then(({ canceled, selection }) => {
        if (canceled)
            return;
        if (selection === 0)
            return player_gamemode(player);
        const { gamemode } = All_Gamemode[selection - 1];
        player.runCommandAsync(`gamemode ${gamemode}`);
        player.sendMessage(`Gamemode set to ${gamemode} mode of ${player.name}.`);
    });
}
function player_gamemode(player) {
    const All_Players = mc.world.getAllPlayers();
    const from = new fm.ActionFormData();
    from.title('Gamemode Player');
    from.body(`§e»§r Select a player to set gamemode.`);
    from.button('All Players\n§7Click to set all players§r', 'textures/ui/xbox_face_button_down');
    All_Players.forEach((player) => {
        from.button(`${player.name}\n§7Gamemode [§c${getGamemode(player)}§7]§r`, api.getFack());
    });
    from.button('Back\n§7Click to back§r', 'textures/ui/xbox_face_button_right');
    from.show(player).then(({ canceled, selection }) => {
        if (canceled)
            return;
        if (selection === All_Players.length + 1)
            return gamemode(player);
        if (selection === 0) {
            const from = new fm.ActionFormData();
            from.title('Gamemode Player');
            from.body(`§e»§r Select a gamemode to set all players.`);
            All_Gamemode.forEach((gamemode) => {
                from.button(gamemode.lable, gamemode.texture);
            });
            from.button('Back\n§7Click to back§r', 'textures/ui/xbox_face_button_right');
            from.show(player).then(({ canceled, selection }) => {
                if (canceled)
                    return;
                if (selection === 4)
                    return player_gamemode(player);
                const { gamemode } = All_Gamemode[selection];
                All_Players.forEach((player) => {
                    player.runCommandAsync(`gamemode ${gamemode}`);
                });
                player.sendMessage(`Gamemode set to ${gamemode} mode of everyone.`);
            });
        }
        if (selection > 0) {
            const target = All_Players[selection - 1];
            const from = new fm.ActionFormData();
            from.title('Gamemode Player');
            from.body(`§e»§r Select a gamemode to set ${target.name}.`);
            All_Gamemode.forEach((gamemode) => {
                from.button(gamemode.lable, gamemode.texture);
            });
            from.button('Back\n§7Click to back§r', 'textures/ui/xbox_face_button_right');
            from.show(player).then(({ canceled, selection }) => {
                if (canceled)
                    return;
                if (selection === 4)
                    return player_gamemode(player);
                const { gamemode } = All_Gamemode[selection];
                target.runCommandAsync(`gamemode ${gamemode}`);
                player.sendMessage(`Gamemode set to ${gamemode} mode of ${target.name}.`);
            });
        }
    });
}
